#!/usr/bin/env bash
# Placeholder stop script for Mule MVP services.
echo "stop-all.sh placeholder: wire real stop logic later."
