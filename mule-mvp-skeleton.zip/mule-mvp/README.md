# Mule MVP – Backend + UI Skeleton

This is a minimal Mule MVP skeleton repository.

It includes:
- Backend service folders (Mule core, AF core, adapters, etc.).
- A console UI skeleton (React + TypeScript structure only).
- Configs, scripts, and CI placeholders.

All files are intentionally tiny so they can be safely replaced or
expanded later from within GitHub.

Do **not** treat this as working code yet – it is a structural scaffold.
