# capmule-core

Skeleton folder for the `capmule-core` service.

- Language / framework: to be wired later (e.g., Java + Spring Boot).
- Purpose: see Mule MVP spec (ET/AF/Mule notes) for detailed behaviour.
- This file exists so that Git tracks the folder and so future code
  generation has a stable place to write into.
