# Mule Console UI (Skeleton)

This folder is a placeholder for the Mule MVP console UI.

Recommended stack:
- React
- TypeScript
- Vite (or similar)
- State management: lightweight (e.g., Zustand, Redux Toolkit, or signals)

For now, this is an empty scaffold so that future UI generation can
drop files directly into `ui/console/src` and `ui/console/public`.
