export function App() {
  return (
    <div style={{ padding: 24, fontFamily: "system-ui, sans-serif" }}>
      <h1>Mule MVP Console (Skeleton)</h1>
      <p>
        This is a minimal placeholder React component. The real console UI will
        be generated and wired later (AF view, Mules, Switchboard, ORCO, etc.).
      </p>
    </div>
  );
}
