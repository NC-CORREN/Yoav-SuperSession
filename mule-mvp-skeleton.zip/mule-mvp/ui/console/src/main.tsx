import { App } from "./App";

export function bootstrap() {
  // Placeholder bootstrap – real Vite/React entrypoint will replace this.
  console.log("Mule MVP console skeleton bootstrap – replace with real ReactDOM.render.");
  console.log(App);
}
