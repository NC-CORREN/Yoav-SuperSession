# Security Policy

Please report vulnerabilities via GitHub Security Advisories.
